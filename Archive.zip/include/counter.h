#ifndef _counter_h_
#define _counter_h_

#include <vector>
#include <string>
#include <map>

#include "node.h"

namespace COUNTER
{
    std::vector<Node *> generateStats(std::string content);
}

#endif
